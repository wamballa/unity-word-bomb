using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Mediation.Editor.Tests")]
