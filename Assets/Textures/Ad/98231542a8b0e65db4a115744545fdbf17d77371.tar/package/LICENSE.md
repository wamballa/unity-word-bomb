Unity Mediation copyright © 2021 Unity Technologies SF
This software is subject to, and made available under, the terms of service for Monetization Services (see https://unity3d.com/legal/one-operate-services-terms-of-service).
Unless expressly provided otherwise, the software under this license is made available strictly on an "AS IS" BASIS WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. Please review the terms of service for details on these and other terms and conditions.
