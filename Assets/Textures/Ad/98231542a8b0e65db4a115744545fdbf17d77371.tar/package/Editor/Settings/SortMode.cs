namespace Unity.Services.Mediation.Settings.Editor
{
    enum SortMode
    {
        Descending,
        Ascending
    }
}
