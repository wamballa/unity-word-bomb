using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Mediation.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Mediation.Build.Editor")]
[assembly: InternalsVisibleTo("UnityEditor.GameGrowth.Helpers.UnityMediation")]
