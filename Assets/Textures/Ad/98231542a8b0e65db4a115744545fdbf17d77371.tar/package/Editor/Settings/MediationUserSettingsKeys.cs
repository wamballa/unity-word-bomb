namespace Unity.Services.Mediation.Settings.Editor
{
    public struct MediationUserSettingsKeys
    {
        public const string forceDynamicLinkingKey = "mediation.build.settings.force-dynamic-linking";
    }
}
