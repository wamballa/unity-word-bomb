using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Mediation.Adapters.Editor")]
[assembly: InternalsVisibleTo("Unity.Mediation.Build.Editor")]
[assembly: InternalsVisibleTo("Unity.Mediation.Editor.Tests")]
