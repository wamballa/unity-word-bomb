#import <UnityMediationSdk/UnityMediationSdk.h>

#ifdef __cplusplus
extern "C" {
#endif

bool UMSPMediationPropertiesGetUseStubbedResponse() {
    return true;
}

void UMSPMediationPropertiesSetUseStubbedResponse(bool value) {
}

#ifdef __cplusplus
}
#endif
